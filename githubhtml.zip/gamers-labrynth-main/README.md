# gamers-labrynth
<!DOCTYPE html>



<html lang= "en">



<head>

	<meta charset= "utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Gamers Labrynth</title>

    <style>
	
        body {
                background-color: #f5f5f5;  /*off-whtie background color */
            }
            
            .centered-text {
            text-align: center;
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh; 
        }
        </style>
</head>
<body>
	
	
	<header>
		<!-- my "gL" logo  -->
        <h1>gL</h1>
		<h5>gamers labrynth</h5>
    
<!-- my buttons  -->
<div class="container">
    <a href="products.html"><button>Products and Services</button></a>
    <a href="functions.html"><button>Functions</button></a>
    <a href="content.html"><button>Content</button></a>
    <a href="architecture.html"><button>Architecture</button></a>
</div>        

<!-- text mission statement  -->
<div class="centered-text">
    <p><strong>Mission Statement</strong><br>
    <br>
    <br>
     Our vision is to empower the gaming community by creating a dynamic online platform that will reach millions of gamers world wide.<br>
     </p>
</div>


</header>
	
<main>
        
</main>
    
<footer>
        <p> &copy; Gamers Labrynth 2024  

		</p> 
</footer>

    
		
    
</body>

</html>
